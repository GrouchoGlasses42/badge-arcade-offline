"""Build a personal LayeredFS catalog from a user's extracted prize archive.

The output SARC contains the user's game assets. Keep it out of public patch
packages; the generated XML registries and schedules contain only asset names.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
import zipfile

from patch_format import write_zip


REGISTRIES = {
    "Categories": ("Category", "pc/rt/Ca/", ".cab.szs", 200),
    "Cranes": ("Crane", "pc/rt/Cr/", ".crb.szs", 1500),
    "CraneIcons": ("CraneIcon", "pc/rt/CI/", ".icb.szs", 2000),
    "Prizes": ("Prize", "pc/rt/Pr/", ".prb.szs", 10000),
    "Attachments": ("Attachment", "pc/rt/At/", ".atb.szs", 200),
    "FixedObjects": ("FixedObject", "pc/rt/FO/", ".fob.szs", 500),
    "CraneInstances": ("CraneInstance", "pc/ci/", ".cib.szs", 2000),
}
ROMFS_FILES = (
    "region_common/Schedule.xml", "region_EUR/common/Schedule.xml",
    "region_EUR/common/sharc/pc.sarc",
)


def read_sarc(blob: bytes) -> dict[str, bytes]:
    """Read the little-endian SARC variant used by the supplied game."""
    if blob[:4] != b"SARC" or blob[6:8] != b"\xff\xfe":
        raise ValueError("Expected a little-endian SARC")
    data_offset = struct.unpack_from("<I", blob, 12)[0]
    count = struct.unpack_from("<H", blob, 26)[0]
    names_offset = 40 + 16 * count
    files = {}
    for index in range(count):
        _, attr, start, end = struct.unpack_from("<4I", blob, 32 + 16 * index)
        pos = names_offset + (attr & 0xFFFFFF) * 4
        if not names_offset <= pos < data_offset or not 0 <= start <= end <= len(blob) - data_offset:
            raise ValueError("Invalid SARC node")
        name = blob[pos:blob.index(b"\0", pos, data_offset)].decode("ascii")
        if name in files:
            raise ValueError("Duplicate SARC name")
        files[name] = blob[data_offset + start:data_offset + end]
    return files


def replace_sarc_files(original: bytes, replacements: dict[str, bytes]) -> bytes:
    """Retain the original name/hash table and rebuild aligned file offsets."""
    files = read_sarc(original)
    if replacements.keys() - files.keys():
        raise ValueError("Replacement is not an existing archive member")
    data_offset = struct.unpack_from("<I", original, 12)[0]
    out = bytearray(original[:data_offset])
    for index, (name, content) in enumerate(files.items()):
        out += bytes(-len(out) % 128)
        start = len(out) - data_offset
        out += replacements.get(name, content)
        struct.pack_into("<II", out, 40 + 16 * index, start, len(out) - data_offset)
    struct.pack_into("<I", out, 8, len(out))
    return bytes(out)


def decompress_yaz0(blob: bytes, limit: int | None = None) -> bytes:
    """Decode bounded Yaz0 data; optionally stop after the resource header."""
    if blob[:4] != b"Yaz0":
        raise ValueError("Expected Yaz0 resource")
    size = struct.unpack_from(">I", blob, 4)[0]
    if size > 8 * 1024 * 1024:
        raise ValueError("Unexpected resource size")
    size = min(size, limit) if limit is not None else size
    out = bytearray()
    pos = 16
    while len(out) < size:
        flags = blob[pos]
        pos += 1
        for bit in range(7, -1, -1):
            if flags & (1 << bit):
                out.append(blob[pos])
                pos += 1
            else:
                first, second = blob[pos:pos + 2]
                pos += 2
                distance = ((first & 15) << 8) + second + 1
                if distance > len(out):
                    raise ValueError("Invalid Yaz0 back-reference")
                length = first >> 4
                if length == 0:
                    length = blob[pos] + 18
                    pos += 1
                else:
                    length += 2
                for _ in range(length):
                    out.append(out[-distance])
                    if len(out) >= size:
                        break
            if len(out) >= size:
                break
    return bytes(out)


def resource_name(blob: bytes, offset: int) -> str:
    return blob[offset:offset + 48].split(b"\0", 1)[0].decode("ascii")


def expand_catalog(archive: bytes, schedule: bytes) -> tuple[bytes, bytes, dict]:
    """Register all bundled assets, after checking every machine dependency."""
    files = read_sarc(archive)
    catalog = ET.fromstring(files["pc/PrizeCollection.xml"])
    counts = {}
    names_by_kind = {}
    for block, (tag, prefix, suffix, capacity) in REGISTRIES.items():
        names = sorted(name[len(prefix):-len(suffix)] for name in files
                       if name.startswith(prefix) and name.endswith(suffix))
        if not names or len(names) > capacity:
            raise ValueError(f"{block} exceeds verified native capacity")
        names_by_kind[block] = names
        node = catalog.find(block)
        if node is None:
            raise ValueError(f"Missing registry {block}")
        node.clear()
        node.set("count", str(len(names)))
        for name in names:
            ET.SubElement(node, tag, name=name)
        counts[block] = len(names)

    category_ids = {}
    for name in names_by_kind["Categories"]:
        raw = decompress_yaz0(files[f"pc/rt/Ca/{name}.cab.szs"], 0x68)
        category_ids[name] = struct.unpack_from("<I", raw, 0x24)[0]
    if len(set(category_ids.values())) != len(category_ids):
        raise ValueError("Duplicate category identity")
    identities = set()
    for name in names_by_kind["Prizes"]:
        raw = decompress_yaz0(files[f"pc/rt/Pr/{name}.prb.szs"], 0xA4)
        category = resource_name(raw, 0x74)
        uid = (category_ids[category], struct.unpack_from("<I", raw, 0x3C)[0])
        if uid in identities:
            raise ValueError("Duplicate prize identity")
        identities.add(uid)

    selectable = []
    selectable_prizes = set()
    for name in names_by_kind["CraneInstances"]:
        raw = decompress_yaz0(files[f"pc/ci/{name}.cib.szs"])
        # Type 2 is the dedicated practice machine. The normal selector accepts
        # type 0 only; its 384 machines already include every bundled prize.
        if struct.unpack_from("<I", raw, 0xC0)[0] == 0:
            selectable.append(name)
            selectable_prizes.update(resource_name(raw, 0x1100 + 48 * i)
                                     for i in range(struct.unpack_from("<I", raw, 0xE0)[0]))
        deps = [f"pc/rt/Cr/{resource_name(raw, 0x60)}.crb.szs",
                f"pc/rt/CI/{resource_name(raw, 0x90)}.icb.szs"]
        for index, block in enumerate(("Prizes", "Attachments", "FixedObjects")):
            _, prefix, suffix, _ = REGISTRIES[block]
            count = struct.unpack_from("<I", raw, 0xE0 + 4 * index)[0]
            if count > 20:
                raise ValueError("Machine dependency table is oversized")
            base = (0x1100, 0x14C0, 0x1880)[index]
            deps += [prefix + resource_name(raw, base + 48 * i) + suffix for i in range(count)]
        if any(dep not in files for dep in deps):
            raise ValueError(f"Incomplete machine {name}")
    if selectable_prizes != set(names_by_kind["Prizes"]):
        raise ValueError("Normal catcher lineup does not cover every bundled prize")
    counts["SelectableMachines"] = len(selectable)

    root = ET.fromstring(schedule)
    items = root.find("Items")
    if items is None:
        raise ValueError("Missing schedule Items")
    for item in list(items):
        if (item.findtext("Key") or "").startswith("DefaultStageName"):
            items.remove(item)
    for index, name in enumerate(selectable):
        item = ET.SubElement(items, "FileItem")
        for tag, value in (("Priority", str(index + 100)), ("DateStartText", "20000101"),
                           ("DateExpireText", "20991231"), ("RegexSetName", "DefaultStage"),
                           ("Key", f"DefaultStageName{index:03d}"), ("Value", name)):
            ET.SubElement(item, tag).text = value
    root.find("ItemsCount").text = str(len(items))
    xml = ET.tostring(catalog, encoding="utf-8", xml_declaration=True)
    replacement = replace_sarc_files(archive, {"pc/PrizeCollection.xml": xml})
    return replacement, ET.tostring(root, encoding="utf-8", xml_declaration=True), counts


def write_personal_package(patch: Path, catalog: Path, destination: Path) -> None:
    """Combine the release patch with user-owned assets for personal use."""
    with zipfile.ZipFile(patch) as source:
        manifest = json.loads(source.read("build.json"))
        if (manifest.get("title_id"), manifest.get("game_version"), manifest.get("release_version")) != (
            "0004000000153600", "1.3.1", "0.3.0",
        ):
            raise ValueError("Expanded update catalog requires the current EUR 1.3.1 release package")
        patch_name = "luma/titles/0004000000153600/code.ips"
        ips = source.read(patch_name)
        if hashlib.sha256(ips).hexdigest() != manifest["ips_sha256"]:
            raise ValueError("Patch fingerprint mismatch")
        instructions = source.read("INSTALL.md")
    assets = {name: (catalog / name).read_bytes() for name in ROMFS_FILES}
    manifest["catalog"] = json.loads((catalog / "catalog.json").read_text())
    manifest["personal_package_contains_game_assets"] = True
    manifest["romfs_sha256"] = {name: hashlib.sha256(data).hexdigest() for name, data in assets.items()}
    files = {
        patch_name: ips,
        "build.json": (json.dumps(manifest, indent=2) + "\n").encode(),
        "INSTALL.md": instructions,
    }
    files.update({"luma/titles/0004000000153600/romfs/" + name: data for name, data in assets.items()})
    write_zip(destination, files)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--schedule", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--patch-package", type=Path, help="Current code-only update ZIP")
    parser.add_argument("--package", type=Path, help="Personal ZIP including your extracted game assets")
    args = parser.parse_args()
    if bool(args.patch_package) != bool(args.package):
        parser.error("--patch-package and --package must be supplied together")
    archive, schedule, counts = expand_catalog(args.archive.read_bytes(), args.schedule.read_bytes())
    for region in ("region_common", "region_EUR/common"):
        dest = args.output / region
        dest.mkdir(parents=True, exist_ok=True)
        (dest / "Schedule.xml").write_bytes(schedule)
    target = args.output / "region_EUR/common/sharc/pc.sarc"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(archive)
    (args.output / "catalog.json").write_text(json.dumps(counts, indent=2) + "\n")
    if args.package:
        write_personal_package(args.patch_package, args.output, args.package)
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
